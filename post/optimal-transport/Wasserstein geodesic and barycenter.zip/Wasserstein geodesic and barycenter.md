# Wasserstein geodesic and barycenter


```python
import numpy as np
import matplotlib.pyplot as plt
plt.style.use("science")
from scipy import stats
import seaborn as sns
```

## Gaussians


```python
n = 1000
x = 2 * np.random.randn(n) + 1
y = 3 * np.random.randn(n) + 30
alpha = stats.norm(1, 2)
beta = stats.norm(30, 3)
```


```python
x.sort()
y.sort()
plt.plot(x, alpha.pdf(x))
plt.plot(y, beta.pdf(y))
plt.show()
```


    
![png](output_4_0.png)
    


## Wasserstein Geodesic

$$F_t(x,y) = (1-t)x + t y$$

with distributions

$$P_{t} = T_{t\#} J , P_0 = \alpha \text{ and } P_1 = \beta$$

where $J$ is the optimal coupling


```python
def geodesic(t):
    return np.array([(1-t)*_x + t * _y for (_x, _y) in zip(x,y)])
```


```python
z1 = geodesic(0.2)
z2 = geodesic(0.5)
z3 = geodesic(0.8)
```


```python
plt.hist(x)
plt.hist(z1, color = "grey", alpha = 0.5)
plt.hist(z2, color = "grey", alpha = 0.5)
plt.hist(z3, color = "grey", alpha = 0.5)
plt.hist(y)
plt.title("Wasserstein Geodesics")
plt.show()
```


    
![png](output_9_0.png)
    



```python
z1_density = stats.gaussian_kde(z1)
z2_density = stats.gaussian_kde(z2)
z3_density = stats.gaussian_kde(z3)
```


```python
plt.plot(x, alpha.pdf(x))
plt.plot(z1, z1_density.pdf(z1), color = "grey")
plt.plot(z2, z2_density.pdf(z2), color = "grey")
plt.plot(z3, z3_density.pdf(z3), color = "grey")
plt.plot(y, beta.pdf(y))
plt.title("Wasserstein Geodesics")
plt.show()
```


    
![png](output_11_0.png)
    


## Wassestein barycenter

Distribution $P$ that realizes $\min \sum_{j=1}^{n} W_p(P, P_j)$


```python
m = 2
z = np.zeros(n)
x.sort()
y.sort()
for i in range(n):
    z[i] = .5 * (x[i] + y[i])
```


```python
plt.hist(x)
plt.hist(z, color = "grey")
plt.hist(y)
plt.title("Wasserstein barycenter")
plt.show()
```


    
![png](output_15_0.png)
    



```python
plt.plot(x, alpha.pdf(x))
plt.plot(z, stats.gaussian_kde(z).pdf(z), color = "grey")
plt.plot(y, beta.pdf(y))
plt.title("Wasserstein barycenter")
```




    Text(0.5, 1.0, 'Wasserstein barycenter')




    
![png](output_16_1.png)
    


## Morphing images


```python
from sklearn.datasets import load_digits
```


```python
data = load_digits()["data"]
target = load_digits()["target"]
m = 8
```

**Morphing an image into another**


```python
plt.matshow(data[0].reshape(m,m), cmap = plt.cm.gray)
plt.title(target[0])
plt.show()
```


    
![png](output_21_0.png)
    



```python
plt.matshow(data[9].reshape(m,m), cmap = plt.cm.gray)
plt.title(target[9])
plt.show()
```


    
![png](output_22_0.png)
    



```python
x = data[0]
y = data[9]
```


```python
z1 = geodesic(0.2)
z2 = geodesic(0.5)
z3 = geodesic(0.8)
```


```python
fig, axes = plt.subplots(1, 5, figsize= (10, 10))
axes[0].imshow(x.reshape(m,m), cmap = plt.cm.gray)
axes[1].imshow(z1.reshape(m,m), cmap = plt.cm.gray)
axes[2].imshow(z2.reshape(m,m), cmap = plt.cm.gray)
axes[3].imshow(z3.reshape(m,m), cmap = plt.cm.gray)
axes[4].imshow(y.reshape(m,m), cmap = plt.cm.gray)
plt.show()
```


    
![png](output_25_0.png)
    


### Wasserstein barycenter of a dataset

Let $X_1, X_2, ..X_m$ be m datasets of size $n$,
The wasserstein barycenter is 
$$Y_{(r)} = \frac{1}{m} \sum_{j=1}^{m}X_{(jr)}$$

where $X_{(j1)} \leq X_{(j2)} \leq \ldots \leq X_{(jn)}$ is the order statistics


```python
m = data.shape[0]
n = data.shape[1]
```


```python
# Barycenter
z = np.zeros(n)
for i in range(n):
    for j in range(m):
        z[i] += data[j][i]
    z[i] /= m
```


```python
plt.imshow(z.reshape(8, 8), cmap = plt.cm.gray)
plt.title("Wasserstein barycenter")
plt.show()
```


    
![png](output_30_0.png)
    


## References

- Luigi Ambrosio, Elia Buré, Daniele Semola, **Lectures on Optimal Transport**


```python

```
