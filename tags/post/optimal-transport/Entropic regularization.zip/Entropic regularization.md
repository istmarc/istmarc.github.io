## Regularized optimal transport

### Import libraries


```python
import numpy as np
import networkx as nx
import math
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.gridspec import GridSpec
plt.style.use("science")
from scipy.optimize import linprog
import pandas as pd
```

### Import data


```python
data = pd.read_csv("../datasets/gaussians_double.csv")
x = data["x"]
n = x.size
y = data["y"]
m = y.size
```


```python
plt.plot(x, color = "darkblue", label=r"$\mu$")
plt.plot(y, color = "maroon", label = r"$\nu$")
plt.legend()
plt.show()
```


    
![png](output_5_0.png)
    


### Entropic regularized optimal transport

$$
\begin{align}
c_{\epsilon} &= \inf_{\gamma \in \Gamma(\mu, \nu)} \int_{X\text{x}Y} c(x,y) d\gamma(x,y) + \epsilon H (\gamma / P) \\
 &= \inf_{\gamma \in \Gamma(\mu, \nu)} \int_{X\text{x}Y} c(x,y) d\gamma(x,y) + \epsilon \gamma(x,y) \log \gamma(x,y) d\gamma(x,y)
\end{align}
$$

where

- $c$: cost function
- $\Gamma$: set of all couplings of $x$ and $y$
- $\gamma$: coupling of $x$ and $y$ in $\Gamma$
- $\epsilon$: regularization term
- $H$: entropy

### Discrete setting

$$
\sum_{i,j} c_{i,j} \gamma_{i,j} + \epsilon \gamma_{i,j} \log \gamma_{i,j}
$$

### Dual formulation

$$
\sum_{i=0}^{n} \phi_i \mu_i + \sum_{j=0}^{m} \psi_j \nu_j - \epsilon \sum_{i,j} \exp(\dfrac{ \phi_i + \psi_j - c_{i,j} }{\epsilon})
$$

where

$$\mu_i = \sum_j \exp(\dfrac{ \phi_i + \psi_j - c_{i,j} }{\epsilon})$$

$$\nu_j = \sum_i \exp(\dfrac{ \phi_i + \psi_j - c_{i,j} }{\epsilon})$$

### Solution to the dual formulation


```python
eps = 0.1
```

**Cost matrix**

$c(x,y) = (x-y)^2$


```python
c = np.zeros((n, m))
for i in range(n):
    for j in range(m):
        c[i,j] = (x[i] - y[j])**2
```


```python
plt.matshow(c, interpolation = 'bilinear')
plt.show()
```


    
![png](output_19_0.png)
    


$A = \exp(-c_{ij} / \epsilon)$


```python
A = np.zeros((n, m))
for i in range(n):
    for j in range(m):
        A[i,j] = np.exp(-c[i,j] / eps)
```


```python
plt.matshow(A, interpolation = 'bilinear')
plt.show()
```


    
![png](output_22_0.png)
    



```python
def sinkhorn_algorithm(z, n, m, mu, nu, itermax = 1000, eps = 1e-3):
    u = np.ones(n)
    u0 = u.copy()
    v = np.ones(m)
    v0 = v.copy()
    for i in range(itermax):
        u = nu / (z @ v)
        v = mu / (z.T @ u)
        if i > 1 and np.linalg.norm(u - u0) < eps and np.linalg.norm(v - v0) < eps:
            print("Sinkhorn algorithm converged after {} iterations".format(i))
            break
        else:
            u0 = u.copy()
            v0 = v.copy()
    return u,v
```


```python
a, b = sinkhorn_algorithm(A, n, m, x, y)
```

    Sinkhorn algorithm converged after 2 iterations


### From dual to primal formulation


```python
z = np.diag(a) @ A @ np.diag(b)
```


```python
plt.matshow(z)
plt.show()
```


    
![png](output_27_0.png)
    



```python
plt.fill(z.sum(0), color = 'silver', label = r'T($\mu$)')
plt.plot(x, color = 'blue', label = r'$\mu$')
plt.legend()
plt.show()
```


    
![png](output_28_0.png)
    



```python
plt.fill(z.sum(1), color = 'silver', label = r'T($\nu$)')
plt.plot(y, color = 'maroon', label = r'$\nu$')
plt.legend()
plt.show()
```


    
![png](output_29_0.png)
    



```python

```
