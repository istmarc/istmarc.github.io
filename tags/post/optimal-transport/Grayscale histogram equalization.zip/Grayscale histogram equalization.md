## Grayscale histogram equalization

### Importing libraries


```python
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams['text.usetex'] = True
plt.style.use("science")
import math
import matplotlib as mpl
from random import shuffle
import pandas as pd
import cv2 as cv
import cvxpy as cp
```

### Import image


```python
img_cv = cv.imread("../_images/van-gogh-1920x1200.jpg")
img_cv = img_cv.astype(np.float32)
img_cv /= 255.
```


```python
img_cv = np.array(img_cv)
img_cv.shape
```




    (1200, 1920, 3)




```python
## Image in RGB format
img = np.zeros(img_cv.shape)
img[:, :, 0] = img_cv[:, :, 2]
img[:, :, 1] = img_cv[:, :, 1]
img[:, :, 2] = img_cv[:, :, 0] 
```


```python
fig, ax = plt.subplots(figsize=(5, 3))
ax.imshow(img, cmap=None)
ax.set_title("Color image")
plt.show()
```


    
![png](output_7_0.png)
    


### Grayscal image


```python
img_grayscale = (img[:, :, 0] + img[:, :, 1] + img[:, :, 2]) / 3.
```


```python
img_grayscale.shape
```




    (1200, 1920)




```python
fig, ax = plt.subplots(figsize=(5, 3))
ax.imshow(img_grayscale, cmap = "gray")
ax.set_title("Grayscale image")
plt.show()
```


    
![png](output_11_0.png)
    


### Grayscale histogram


```python
fig, ax = plt.subplots(figsize=(5, 2))
ax.hist(img_grayscale.flatten(), color = "gray")
ax.set_title("Histogram of grayscale image")
plt.show()
```


    
![png](output_13_0.png)
    


### Histogram equalization


```python
hist_equal = np.linspace(0, 1, img_grayscale.size)
img_equal = hist_equal.reshape(img_grayscale.shape)
```


```python
img_equal = img_grayscale.copy().flatten()
img_equal[np.argsort(img_grayscale.flatten())] = hist_equal
img_equal = img_equal.reshape(img_grayscale.shape)
```


```python
fig, axes = plt.subplots(1, 2, figsize=(10, 3))
axes[0].imshow(img_grayscale, cmap = "gray")
axes[0].set_title("Grayscale image")
axes[1].imshow(img_equal, cmap = "gray")
axes[1].set_title("Equal histogram")
plt.show()
```


    
![png](output_17_0.png)
    


**Histograms side by side**


```python
fig, axes = plt.subplots(1, 2, figsize=(10, 3))
axes[0].hist(img_grayscale.flatten(), color = "gray")
axes[0].set_title("Histogram")
axes[1].hist(img_equal.flatten(), color = "silver")
axes[1].set_title("Equal histogram")
plt.show()
```


    
![png](output_19_0.png)
    


## References

- Gabriel Peyré, **Computational optimal transport**


```python

```
